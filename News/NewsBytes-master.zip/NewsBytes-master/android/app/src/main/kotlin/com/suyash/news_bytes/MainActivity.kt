package com.suyash.news_bytes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
