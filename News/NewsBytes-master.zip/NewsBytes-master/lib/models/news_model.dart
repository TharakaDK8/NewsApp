class NewsModel{
  String title;
  String url;
  String urlImage;
  String publishedDate;

  NewsModel(this.title,this.url,this.urlImage,this.publishedDate);
}