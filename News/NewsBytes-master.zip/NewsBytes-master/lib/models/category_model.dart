class CategoryModel {

  String title;
  String url;
  String urlImage;
  String publishedDate;
  String source;

  CategoryModel(this.title, this.url, this.urlImage, this.publishedDate,this.source);
}
