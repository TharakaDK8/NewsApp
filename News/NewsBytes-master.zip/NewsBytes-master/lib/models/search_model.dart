class SearchModel{
  String title;
  String url;
  String urlImage;
  String sourceName;

  SearchModel(this.title,this.url,this.urlImage,this.sourceName);
}