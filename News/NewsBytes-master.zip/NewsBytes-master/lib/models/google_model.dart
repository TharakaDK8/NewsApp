class GoogleModel{
  String title;
  String url;
  String urlImage;
  String date;

  GoogleModel(this.title,this.url,this.urlImage,this.date);
}