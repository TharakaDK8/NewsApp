package arman.corp.gennews

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
