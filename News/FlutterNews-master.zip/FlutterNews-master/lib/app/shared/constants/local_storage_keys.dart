class AppLocalStorageKeys {
  static const bookmarks = 'bookmarks';
  static const themeMode = 'themeMode';
}