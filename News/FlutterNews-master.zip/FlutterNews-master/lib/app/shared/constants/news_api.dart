const String BASE_URL = 'http://newsapi.org/v2';

class ApiUrls {
  static const topHeadlines = '/top-headlines';
  static const everything = '/everything';
  static const sources = '/sources';
}
