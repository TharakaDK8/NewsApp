class AppRoutes {
  static const login = '/login';
  static const signUp = '/signUp';
  static const start = '/start';
  static const trending = '/trending';
}
