// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shared_preferences_service.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $SharedPreferencesService = BindInject(
  (i) => SharedPreferencesService(),
  singleton: true,
  lazy: true,
);
