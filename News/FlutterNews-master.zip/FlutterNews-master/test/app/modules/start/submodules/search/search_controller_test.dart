import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/search/search_controller.dart';
import 'package:flutter_news_app/app/modules/start/submodules/search/search_module.dart';

void main() {
  initModule(SearchModule());
  // SearchController search;
  //
  setUp(() {
    //     search = SearchModule.to.get<SearchController>();
  });

  group('SearchController Test', () {
    //   test("First Test", () {
    //     expect(search, isInstanceOf<SearchController>());
    //   });

    //   test("Set Value", () {
    //     expect(search.value, equals(0));
    //     search.increment();
    //     expect(search.value, equals(1));
    //   });
  });
}
