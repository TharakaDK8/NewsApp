import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/search/components/date_picker/date_picker_widget.dart';

void main() {
//  testWidgets('DatePickerWidget has message', (tester) async {
//    await tester.pumpWidget(buildTestableWidget(DatePickerWidget()));
//    final textFinder = find.text('DatePicker');
//    expect(textFinder, findsOneWidget);
//  });
}
