import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/trending/trending_controller.dart';
import 'package:flutter_news_app/app/modules/start/submodules/trending/trending_module.dart';

void main() {
  initModule(TrendingModule());
  // TrendingController trending;
  //
  setUp(() {
    //     trending = TrendingModule.to.get<TrendingController>();
  });

  group('TrendingController Test', () {
    //   test("First Test", () {
    //     expect(trending, isInstanceOf<TrendingController>());
    //   });

    //   test("Set Value", () {
    //     expect(trending.value, equals(0));
    //     trending.increment();
    //     expect(trending.value, equals(1));
    //   });
  });
}
