import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/settings/components/reset_password/reset_password_widget.dart';

void main() {
//  testWidgets('ResetPasswordWidget has message', (tester) async {
//    await tester.pumpWidget(buildTestableWidget(ResetPasswordWidget()));
//    final textFinder = find.text('ResetPassword');
//    expect(textFinder, findsOneWidget);
//  });
}
