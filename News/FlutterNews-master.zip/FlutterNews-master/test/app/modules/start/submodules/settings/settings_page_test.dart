import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/settings/settings_page.dart';

void main() {
  testWidgets('SettingsPage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(SettingsPage(title: 'Settings')));
    //  final titleFinder = find.text('Settings');
    //  expect(titleFinder, findsOneWidget);
  });
}
