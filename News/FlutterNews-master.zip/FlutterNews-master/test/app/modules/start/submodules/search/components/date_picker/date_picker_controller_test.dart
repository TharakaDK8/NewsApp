import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/search/components/date_picker/date_picker_controller.dart';
import 'package:flutter_news_app/app/modules/start/submodules/search/search_module.dart';

void main() {
  initModule(SearchModule());
  // DatePickerController datepicker;
  //
  setUp(() {
    //     datepicker = SearchModule.to.get<DatePickerController>();
  });

  group('DatePickerController Test', () {
    //   test("First Test", () {
    //     expect(datepicker, isInstanceOf<DatePickerController>());
    //   });

    //   test("Set Value", () {
    //     expect(datepicker.value, equals(0));
    //     datepicker.increment();
    //     expect(datepicker.value, equals(1));
    //   });
  });
}
