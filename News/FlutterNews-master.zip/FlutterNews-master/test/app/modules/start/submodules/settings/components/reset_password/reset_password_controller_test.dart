import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/settings/components/reset_password/reset_password_controller.dart';
import 'package:flutter_news_app/app/modules/start/submodules/settings/settings_module.dart';

void main() {
  initModule(SettingsModule());
  // ResetPasswordController resetpassword;
  //
  setUp(() {
    //     resetpassword = SettingsModule.to.get<ResetPasswordController>();
  });

  group('ResetPasswordController Test', () {
    //   test("First Test", () {
    //     expect(resetpassword, isInstanceOf<ResetPasswordController>());
    //   });

    //   test("Set Value", () {
    //     expect(resetpassword.value, equals(0));
    //     resetpassword.increment();
    //     expect(resetpassword.value, equals(1));
    //   });
  });
}
