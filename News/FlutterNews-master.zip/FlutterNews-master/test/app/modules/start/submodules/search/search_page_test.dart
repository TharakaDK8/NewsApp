import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/search/search_page.dart';

void main() {
  testWidgets('SearchPage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(SearchPage(title: 'Search')));
    //  final titleFinder = find.text('Search');
    //  expect(titleFinder, findsOneWidget);
  });
}
