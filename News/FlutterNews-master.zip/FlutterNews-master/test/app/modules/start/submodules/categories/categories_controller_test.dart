import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/modules/start/submodules/categories/categories_controller.dart';
import 'package:flutter_news_app/app/modules/start/submodules/categories/categories_module.dart';

void main() {
  initModule(CategoriesModule());
  // CategoriesController categories;
  //
  setUp(() {
    //     categories = CategoriesModule.to.get<CategoriesController>();
  });

  group('CategoriesController Test', () {
    //   test("First Test", () {
    //     expect(categories, isInstanceOf<CategoriesController>());
    //   });

    //   test("Set Value", () {
    //     expect(categories.value, equals(0));
    //     categories.increment();
    //     expect(categories.value, equals(1));
    //   });
  });
}
