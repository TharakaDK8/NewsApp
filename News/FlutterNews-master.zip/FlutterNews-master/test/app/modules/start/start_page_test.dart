import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:flutter_news_app/app/modules/start/start_page.dart';

void main() {
  testWidgets('StartPage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(StartPage(title: 'Start')));
    //  final titleFinder = find.text('Start');
    //  expect(titleFinder, findsOneWidget);
  });
}
