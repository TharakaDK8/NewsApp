import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/modules/start/start_controller.dart';
import 'package:flutter_news_app/app/modules/start/start_module.dart';

void main() {
  initModule(StartModule());
  // StartController start;
  //
  setUp(() {
    //     start = StartModule.to.get<StartController>();
  });

  group('StartController Test', () {
    //   test("First Test", () {
    //     expect(start, isInstanceOf<StartController>());
    //   });

    //   test("Set Value", () {
    //     expect(start.value, equals(0));
    //     start.increment();
    //     expect(start.value, equals(1));
    //   });
  });
}
