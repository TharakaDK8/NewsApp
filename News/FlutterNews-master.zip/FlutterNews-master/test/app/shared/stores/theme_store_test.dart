import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/shared/stores/theme_store.dart';
import 'package:flutter_news_app/app/app_module.dart';

void main() {
  initModule(AppModule());
  // ThemeStore theme;
  //
  setUp(() {
    //     theme = AppModule.to.get<ThemeStore>();
  });

  group('ThemeStore Test', () {
    //   test("First Test", () {
    //     expect(theme, isInstanceOf<ThemeStore>());
    //   });

    //   test("Set Value", () {
    //     expect(theme.value, equals(0));
    //     theme.increment();
    //     expect(theme.value, equals(1));
    //   });
  });
}
