import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/shared/stores/query_store.dart';
import 'package:flutter_news_app/app/app_module.dart';

void main() {
  initModule(AppModule());
  // QueryStore query;
  //
  setUp(() {
    //     query = AppModule.to.get<QueryStore>();
  });

  group('QueryStore Test', () {
    //   test("First Test", () {
    //     expect(query, isInstanceOf<QueryStore>());
    //   });

    //   test("Set Value", () {
    //     expect(query.value, equals(0));
    //     query.increment();
    //     expect(query.value, equals(1));
    //   });
  });
}
