import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/shared/stores/bookmark_store.dart';
import 'package:flutter_news_app/app/app_module.dart';

void main() {
  initModule(AppModule());
  // BookmarkStore bookmark;
  //
  setUp(() {
    //     bookmark = AppModule.to.get<BookmarkStore>();
  });

  group('BookmarkStore Test', () {
    //   test("First Test", () {
    //     expect(bookmark, isInstanceOf<BookmarkStore>());
    //   });

    //   test("Set Value", () {
    //     expect(bookmark.value, equals(0));
    //     bookmark.increment();
    //     expect(bookmark.value, equals(1));
    //   });
  });
}
