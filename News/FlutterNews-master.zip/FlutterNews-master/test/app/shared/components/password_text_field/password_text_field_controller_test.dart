import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/shared/components/password_text_field/password_text_field_controller.dart';
import 'package:flutter_news_app/app/app_module.dart';

void main() {
  initModule(AppModule());
  // PasswordTextFieldController passwordtextfield;
  //
  setUp(() {
    //     passwordtextfield = AppModule.to.get<PasswordTextFieldController>();
  });

  group('PasswordTextFieldController Test', () {
    //   test("First Test", () {
    //     expect(passwordtextfield, isInstanceOf<PasswordTextFieldController>());
    //   });

    //   test("Set Value", () {
    //     expect(passwordtextfield.value, equals(0));
    //     passwordtextfield.increment();
    //     expect(passwordtextfield.value, equals(1));
    //   });
  });
}
