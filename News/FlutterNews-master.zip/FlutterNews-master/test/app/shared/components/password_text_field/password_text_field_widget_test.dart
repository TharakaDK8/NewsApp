import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:flutter_news_app/app/shared/components/password_text_field/password_text_field_widget.dart';

void main() {
//  testWidgets('PasswordTextFieldWidget has message', (tester) async {
//    await tester.pumpWidget(buildTestableWidget(PasswordTextFieldWidget()));
//    final textFinder = find.text('PasswordTextField');
//    expect(textFinder, findsOneWidget);
//  });
}
