import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:flutter_news_app/app/shared/components/bookmark/bookmark_widget.dart';

void main() {
//  testWidgets('BookmarkWidget has message', (tester) async {
//    await tester.pumpWidget(buildTestableWidget(BookmarkWidget()));
//    final textFinder = find.text('Bookmark');
//    expect(textFinder, findsOneWidget);
//  });
}
