import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_news_app/app/shared/components/bookmark/bookmark_controller.dart';
import 'package:flutter_news_app/app/app_module.dart';

void main() {
  initModule(AppModule());
  // BookmarkController bookmark;
  //
  setUp(() {
    //     bookmark = AppModule.to.get<BookmarkController>();
  });

  group('BookmarkController Test', () {
    //   test("First Test", () {
    //     expect(bookmark, isInstanceOf<BookmarkController>());
    //   });

    //   test("Set Value", () {
    //     expect(bookmark.value, equals(0));
    //     bookmark.increment();
    //     expect(bookmark.value, equals(1));
    //   });
  });
}
