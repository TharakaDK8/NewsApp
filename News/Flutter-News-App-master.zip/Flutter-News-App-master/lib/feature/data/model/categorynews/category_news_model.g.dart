// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_news_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CategoryNewsModel _$CategoryNewsModelFromJson(Map<String, dynamic> json) {
  return CategoryNewsModel(
    image: json['image'] as String,
    title: json['title'] as String,
  );
}

Map<String, dynamic> _$CategoryNewsModelToJson(CategoryNewsModel instance) =>
    <String, dynamic>{
      'image': instance.image,
      'title': instance.title,
    };
