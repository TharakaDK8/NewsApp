class ConstantConfig {
  final String keyNewsApi = 'YOUR API KEY';
}